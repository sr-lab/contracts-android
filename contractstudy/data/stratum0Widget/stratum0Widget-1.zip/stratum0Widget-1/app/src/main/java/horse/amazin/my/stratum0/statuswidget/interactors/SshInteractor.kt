package horse.amazin.my.stratum0.statuswidget.interactors

import android.os.SystemClock
import horse.amazin.my.stratum0.statuswidget.BuildConfig
import horse.amazin.my.stratum0.statuswidget.R
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.common.DisconnectReason
import net.schmizz.sshj.transport.TransportException
import net.schmizz.sshj.userauth.UserAuthException
import net.schmizz.sshj.userauth.password.PasswordUtils
import okhttp3.internal.closeQuietly
import timber.log.Timber
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException


class SshInteractor {
    fun performSshLogin(sshPrivateKey: String, sshPassword: String, user: String): Int? {
        val server = if (BuildConfig.DEBUG) "192.168.178.21" else "basilisk"

        val sshClient = SSHClient()

        // Accept all clients. Security reasoning: The only thing a MitM-attacker could do here is
        // open the door on a network where the user doesn't expect the mechanism to work.
        sshClient.addHostKeyVerifier { _, _, _ -> true }
        sshClient.connectTimeout = 3000

        val keys = try {
            sshClient.loadKeys(sshPrivateKey, null, PasswordUtils.createOneOff(sshPassword.toCharArray()))
        } catch (e: IOException) {
            Timber.e(e, "Failed loading identity!")
            return R.string.ssh_error_identity
        }

        Timber.d("Trying to connect...")

        try {
            sshClient.connect(server)
            sshClient.authPublickey(user, keys)
            val sshSession = sshClient.startSession()
            val shell = sshSession.startShell()

            val startTime = SystemClock.elapsedRealtime()
            while (!shell.isEOF) {
                try {
                    Thread.sleep(100)
                } catch (e: InterruptedException) { }
                if (SystemClock.elapsedRealtime() - startTime > MAX_CONNECTION_TIME) {
                    shell.closeQuietly()
                    break
                }
            }

            val receivedText = shell.inputStream.bufferedReader().readText()
            Timber.d("Received text: %s", receivedText)
        } catch (e: UserAuthException) {
            Timber.e(e)
            return R.string.ssh_error_auth
        } catch (e: TransportException) {
            Timber.e(e, "Disconnect reason: %s", e.disconnectReason)
            return when (e.disconnectReason) {
                DisconnectReason.HOST_KEY_NOT_VERIFIABLE -> R.string.ssh_error_serverauth
                DisconnectReason.NO_MORE_AUTH_METHODS_AVAILABLE -> R.string.ssh_error_auth
                else -> R.string.ssh_error_network
            }
        } catch (e: UnknownHostException) {
            Timber.e(e)
            return R.string.ssh_error_resolve
        } catch (e: SocketTimeoutException) {
            Timber.e(e)
            return R.string.ssh_error_timeout
        } catch (e: ConnectException) {
            Timber.e(e)
            return R.string.ssh_error_connect
        } catch (e: IOException) {
            Timber.e(e)
            return R.string.ssh_error_unknown
        }

        Timber.d("Connect successful")

        return null
    }

    companion object {
        private val MAX_CONNECTION_TIME = 3500
    }

}