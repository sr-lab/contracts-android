Original idea
=============
- [Gram Games Team](http://gram.gs/)

Programming
===========
- [Lonami Exo](https://lonamiwebs.github.io/)

Art
===
- [Lonami Exo](https://lonamiwebs.github.io/)

Sounds
======
- `game_over` by [BerduSmith](http://freesound.org/people/BerduSmith/sounds/335395/`)
- `piece_drop` by [cabled_mess](http://freesound.org/people/cabled_mess/sounds/350906/)
- `invalid_drop` by [fins](http://freesound.org/people/fins/sounds/146726/)
- `strip_clear` by [Kastenfrosch](http://freesound.org/people/Kastenfrosch/sounds/162461/)
- `take_pieces` by [LloydEvans09](http://freesound.org/people/LloydEvans09/sounds/321806/)
